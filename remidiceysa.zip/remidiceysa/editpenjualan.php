<?php
session_start();
if(!isset($_SESSION['id'])){
    header("Location: login.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/style.css">
    <title>Ceysa | Edit penjualan</title>
</head>

<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <a href="#" class="logo">&ensp;
            <div class="logo-name"><span>Ceysa</span>Vionindra</div>
        </a>
        <ul class="side-menu">
            <li><a href="tabelproduk.php"><i class='bx bxs-dashboard'></i>Tabel Produk</a></li>
            <li class="active"><a href="tabelpenjualan.php"><i class='bx bxs-dashboard'></i>Tabel Penjualan</a></li>
            <li><a href="tabeldetail.php"><i class='bx bxs-dashboard'></i>Tabel Detail</a></li>
        <ul class="side-menu">
            <li>
            <a href="logout.php" <?php echo $_SESSION['id']; ?> class="logout">
                    <i class='bx bx-log-out-circle'></i>
                    Logout
                </a>
            </li>
        </ul>
    </div>
    <!-- End of Sidebar -->

    <!-- Main Content -->
    <div class="content">
        <!-- Navbar -->
        <nav>
            <i class='bx bx-menu'></i>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button class="search-btn" type="submit"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="theme-toggle" hidden>
            <label for="theme-toggle" class="theme-toggle"></label>
            <a href="#" class="notif">
                <i class='bx bx-bell'></i>
                <span class="count">12</span>
            </a>
        </nav>

        <!-- End of Navbar -->

        <main>
            <div class="header">
                <div class="left">
                    <h1>Dashboard</h1>
                    <ul class="breadcrumb">
                        <li><a href="#">
                                Analytics
                            </a></li>
                        /
                        <li><a href="#" class="active">Ceysa</a></li>
                    </ul>
                </div>
            </div>

            <div class="bottom-data">
                <div class="orders">
                    <div class="header">
                        <i class='bx bx-receipt'></i>
                        <h3>Edit Penjualan</h3>
                        <i class='bx bx-filter'></i>
                        <i class='bx bx-search'></i>
                    </div>

                    <?php
                                include 'koneksi.php';
                                if (isset($_POST["b"])) {
                                    $PenjualanID = $_POST["PenjualanID"];
                                    $TanggalPenjualan = $_POST["TanggalPenjualan"];
                                    
                                    
                                    $input = mysqli_query($koneksi, "UPDATE penjualan SET TanggalPenjualan='$TanggalPenjualan' WHERE PenjualanID='$PenjualanID'");
                                    if ($input) {
                                        echo "<div class='alert alert-success' >Data penjualan berhasil di edit!</div> ";
                                    } else {
                                        echo "<script>alert('Gagal menyimpan');</script>";
                                    }
                                    
                                }
                                ?>
                                 
                                 <?php
                                    include 'koneksi.php';
                                    $PenjualanID = $_GET['PenjualanID'];
                                    $update = mysqli_query($koneksi, "SELECT * from penjualan WHERE PenjualanID='$PenjualanID'");
                                    foreach ($update as $row) {

                                    ?>




                    <form method="post" action="">
                        <div class="form-group">
                            <label>Penjualan ID</label>
                            <input type="text" style="
                                width: 100%;
                                padding: 10px;
                                font-size: 14px;
                                border: 1px solid #ccc;
                                border-radius: 5px;
                                transition: border-color 0.3s ease;
                                border-color: #007bff;" name="PenjualanID" value="<?php echo $row['PenjualanID']; ?>" readonly>
                        </div>
                        <br>
                        <div class="form-group">
                            <label>Tanggal Penjualan</label>
                            <input type="date" style="
                                width: 100%;
                                padding: 10px;
                                font-size: 14px;
                                border: 1px solid #ccc;
                                border-radius: 5px;
                                transition: border-color 0.3s ease;
                                border-color: #007bff;" name="TanggalPenjualan" value="<?php echo $row['TanggalPenjualan']; ?>">
                        </div>
                        <br>
                        <div class="form-group">
                            <label>Total Harga</label>
                            <input type="text" style="
                                width: 100%;
                                padding: 10px;
                                font-size: 14px;
                                border: 1px solid #ccc;
                                border-radius: 5px;
                                transition: border-color 0.3s ease;
                                border-color: #007bff;" name="TotalHarga" value="<?php echo $row['TotalHarga']; ?>" readonly>
                        </div>
                        <br>
                        <a href="tabelpenjualan.php" button type="button" style="background-color: #ffd700; /* Warna kuning */
                                border: none;
                                color: white;
                                width: 13%;
                                padding: 5px 15px;
                                text-align: center;
                                text-decoration: none;
                                display: inline-block;
                                font-size: 16px;
                                margin: 4px 2px;
                                transition-duration: 0.4s;
                                cursor: pointer;
                                border-radius: 10px;
                                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">KEMBALI</a>
                                
                        <button type="submit" name="b" class="btn btn-primary"style="float: right; background-color: var(--primary); /* Warna kuning */
                                border: none;
                                color: white;
                                width: 13%;
                                padding: 5px 15px;
                                text-align: center;
                                text-decoration: none;
                                display: inline-block;
                                font-size: 16px;
                                margin: 4px 2px;
                                transition-duration: 0.4s;
                                cursor: pointer;
                                border-radius: 8px;
                                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);" onclick="showConfirmDialog()">EDIT</button>
                        <script>
                            function showConfirmDialog() {
                                var result = confirm("Apakah data penjualan yang Anda edit sudah benar?");
                            }
                        </script>
                        <div style="text-align: center;">
                            <h5><a href="tabelpenjualan.php">Tampilkan Data Penjualan</a></h5>
                        </div>
                    </form>
                    <?php } ?>

                </div>
            </div>

        </main>

    </div>

    <script src="assets/index.js"></script>
</body>

</html>