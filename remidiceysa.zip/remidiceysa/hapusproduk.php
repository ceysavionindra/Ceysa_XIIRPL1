<?php
session_start();
if(!isset($_SESSION['id'])){
    header("Location: login.php");
    exit();
}
?>


<?php
include 'koneksi.php';
$ProdukID = $_GET["ProdukID"];
$query = "delete from produk where ProdukID='$ProdukID'";
if (mysqli_query($koneksi, $query)) {
    echo "<script>alert('Data produk berhasil di hapus!');
    document.location='tabelproduk.php';
    </script>"; 
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($connection);
}
?>