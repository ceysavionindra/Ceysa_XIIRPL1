<?php
session_start();
if(!isset($_SESSION['id'])){
    header("Location: login.php");
    exit();
}
?>


<?php
include 'koneksi.php';
$DetailID = $_GET["DetailID"];
$query = "delete from detail_penjualan where DetailID='$DetailID'";
if (mysqli_query($koneksi, $query)) {
    echo "<script>alert('Data detail berhasil di hapus!');
    document.location='tabeldetail.php';
    </script>"; 
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($connection);
}
?>