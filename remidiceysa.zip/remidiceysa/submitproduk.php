<?php
include 'koneksi.php';

session_start();
if(!isset($_SESSION['id'])){
    header("Location: login.php");
    exit();
}

if (isset($_POST['a'])) {
    
    $ProdukID = $_POST['ProdukID'];
    $NamaProduk = $_POST['NamaProduk'];
    $Harga = $_POST['Harga'];
    $Stok = $_POST['Stok'];

    $query = "INSERT INTO produk (ProdukID, NamaProduk, Harga, Stok) VALUES (?, ?, ?, ?)";
    
    $stmt = mysqli_prepare($koneksi, $query);

    mysqli_stmt_bind_param($stmt, 'isss', $ProdukID, $NamaProduk, $Harga, $Stok);

    $result = mysqli_stmt_execute($stmt);

    if ($result) {
        echo "<div class='alert alert-success' >Data produk berhasil disimpan!</div> ";
        header("Location: tambahproduk.php");
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }

    mysqli_stmt_close($stmt);
}
?>