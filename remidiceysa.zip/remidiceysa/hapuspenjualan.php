<?php
session_start();
if(!isset($_SESSION['id'])){
    header("Location: login.php");
    exit();
}
?>


<?php
include 'koneksi.php';
$PenjualanID = $_GET["PenjualanID"];
$query = "delete from penjualan where PenjualanID='$PenjualanID'";
if (mysqli_query($koneksi, $query)) {
    echo "<script>alert('Data penjualan berhasil di hapus!');
    document.location='tabelpenjualan.php';
    </script>"; 
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($connection);
}
?>