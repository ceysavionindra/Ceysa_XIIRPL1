<?php
$server = "localhost";
$username = "root";
$password = "";
$db = "remidi_ceysa";

$koneksi = new mysqli
("$server","$username","$password","$db");

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>