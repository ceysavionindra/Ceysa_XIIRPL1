<?php
session_start();
if(!isset($_SESSION['id'])){
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/style.css">
    <title>Ceysa | Tabel produk</title>
</head>

<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <a href="#" class="logo">&ensp;
            <div class="logo-name"><span>Ceysa</span>Vionindra</div>
        </a>
        <ul class="side-menu">
            <li><a href="tabelproduk.php"><i class='bx bxs-dashboard'></i>Tabel Produk</a></li>
            <li><a href="tabelpenjualan.php"><i class='bx bxs-dashboard'></i>Tabel Penjualan</a></li>
            <li class="active"><a href="tabeldetail.php"><i class='bx bxs-dashboard'></i>Tabel Detail</a></li>
        <ul class="side-menu">
            <li>
            <a href="logout.php" <?php echo $_SESSION['id']; ?> class="logout">
                    <i class='bx bx-log-out-circle'></i>
                    Logout
                </a>
            </li>
        </ul>
    </div>
    <!-- End of Sidebar -->

    <!-- Main Content -->
    <div class="content">
        <!-- Navbar -->
        <nav>
            <i class='bx bx-menu'></i>
            <form action="#">
                <div class="form-input">
                    <input id="searchInput" placeholder="Search...">
                    <button class="search-btn" type=""><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="theme-toggle" hidden>
            <label for="theme-toggle" class="theme-toggle"></label>
            <a href="#" class="notif">
                <i class='bx bx-bell'></i>
                <span class="count"></span>
            </a>
        </nav>

        <!-- End of Navbar -->

        <main>
            <div class="header">
                <div class="left">
                    <h1>Dashboard</h1>
                    <ul class="breadcrumb">
                        <li><a href="#">
                                Analytics
                            </a></li>
                        /
                        <li><a href="#" class="active">Ceysa</a></li>
                    </ul>
                </div>
            </div>

            <div class="bottom-data">
                <div class="orders">
                    <div class="header">
                        <i class='bx bx-receipt'></i>
                        <h3>Tabel Detail Penjualan</h3>
                    </div>
                    <table id="dataTable">
                        <thead>
                            <tr>
                                <th width="100px">Detail ID</th>
                                <th width="300px">Penjualan ID</th>
                                <th width="200px">Produk ID</th>
                                <th width="200px">Jumlah Produk</th>
                                <th width="200px">Sub Total</th>
                                <th width="50px">Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                                        include 'koneksi.php';
                                        $input = mysqli_query($koneksi, "SELECT * from detail_penjualan");

                                        foreach ($input as $row) {
                                            echo "<tr>
                                            <td>" . $row['DetailID'] . "</td>
                                            <td>" . $row['PenjualanID'] . "</td>
                                            <td>" . $row['ProdukID'] . "</td>
                                            <td>" . $row['JumlahProduk'] . "</td>
                                            <td>" . $row['SubTotal'] . "</td>
                                            <td><a href='editdetail.php?DetailID=$row[DetailID]'>Edit</a> <br>
                                            <a href='hapusdetail.php?DetailID=$row[DetailID]' onclick=\"return confirm('Apakah anda yakin ingin menghapus data produk ini?');\">Delete</a>"
                                            ;

                                        }
                                    ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </main>

    </div>

    <script src="assets/index.js"></script>

    <script>
        document.getElementById('searchInput').addEventListener('input', function () {
          searchTable();
        });
    
        function searchTable() {
          var input, filter, table, tr, td, i, j, txtValue;
          input = document.getElementById('searchInput');
          filter = input.value.toUpperCase();
          table = document.getElementById('dataTable');
          tr = table.getElementsByTagName('tr');
    
          for (i = 0; i < tr.length; i++) {
            var found = false;
            for (j = 0; j < tr[i].cells.length; j++) {
              td = tr[i].getElementsByTagName('td')[j];
              if (td) {
                txtValue = td.textContent || td.innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                  found = true;
                  break;
                }
              }
            }
            if (found) {
              tr[i].style.display = '';
            } else {
              tr[i].style.display = 'none';
            }
          }
        }
        var tableContainer = document.getElementById('tableContainer');
        tableContainer.addEventListener('wheel', function (event) {
        if (event.deltaY !== 0) {
            tableContainer.scrollTop += event.deltaY;
            event.preventDefault();
        }
        });
      </script>
</body>

</html>