<?php
include 'koneksi.php';

session_start();
if(!isset($_SESSION['id'])){
    header("Location: login.php");
    exit();
}

if (isset($_POST['b'])) {
    
    $PenjualanID = $_POST['PenjualanID'];
    $TanggalPenjualan = $_POST['TanggalPenjualan'];
    $TotalHarga = $_POST['TotalHarga'];

    $query = "INSERT INTO penjualan (PenjualanID, TanggalPenjualan, TotalHarga) VALUES (?, ?, ?)";
    
    $stmt = mysqli_prepare($koneksi, $query);

    mysqli_stmt_bind_param($stmt, 'iss', $PenjualanID, $TanggalPenjualan, $TotalHarga);

    $result = mysqli_stmt_execute($stmt);

    if ($result) {
        echo "<div class='alert alert-success' >Data penjualan berhasil disimpan!</div> ";
        header("Location: tambahpenjualan.php");
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }

    mysqli_stmt_close($stmt);
}
?>